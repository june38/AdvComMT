﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//5631347921  Sorawit Watcharakamthorn
//5631363921 Sutatta Adisornvorakij
namespace _2190152_lab06_inClass_56313479_56313639
{
    abstract class Cybertron
    {
        private int life = 0;
        Point position = new Point();
        Boolean isVehicle = true;
        
        public int getX(){
            if (position.getX() < 0) {Console.Write("negative x: " ); position.setX(250);}
            else if (position.getX() > 500) { Console.Write("too large x: "); position.setX(250); }
            return position.getX();
        }
        public int getY(){
            if (position.getY() < 0){ Console.Write("negative y: "); position.setY(250);}
            else if (position.getY() > 500) {Console.Write("too large y: " ); position.setY(250);}
            return position.getY();
        }
        public abstract void moveHorizontal(int x);
        public abstract void moveVertical(int y);
        public void transform(){
            if(isVehicle==true){
                isVehicle=false;
            }else isVehicle=true;
        }

        public Boolean getVehicle()
        {
            return this.isVehicle;
        }
        public void setVehicle(Boolean a)
        {
            this.isVehicle = a;
        }
        public void setLife(int a){
            life = a;
        }
        public int getLife(){

            if (this.life < 0) { Console.Write("negative life: "); this.life = 20; }
            else if (this.life > 20) { Console.Write("excess life: "); this.life = 20; }
            return this.life;
        }
        public void setPosition(int x,int y){
            this.position.setX(x);
            this.position.setY(y);
        }
        public Point getPosition(){
            Point a = new Point(position.getX(),position.getY());
            return a;
        }
    }
    class Point{
        private int x;
        private int y;
        public Point(){
            x=0;y=0;
        }
        public Point(int x,int y){
            this.x=x; this.y=y;
        }
        public int getX(){
            return this.x;
        }
        public int getY() {
            return this.y;
        }
        public void setX(int x)
        {
            this.x = x;
        }
        public void setY(int y)
        {
            this.y = y;
        }
    }

    class Autobot : Cybertron{
        private int spirit = 0;
        public void setSpirit(int a){
           
                spirit=a;
            
        }
        public int getSpirit(){

            if (this.spirit < 0) {Console.Write("negative spirit : "); this.spirit=5;}
            else if (this.spirit > 10) { Console.Write("too much spirit: "); this.spirit = 5; }
            return this.spirit;
        }
        public override void moveHorizontal(int x){
            int value = base.getPosition().getX() + x + spirit;
            if (value < 0) { value = 0; }
            if (value >500) { value = 500; }
            base.getPosition().setX(value);
            Console.WriteLine("A moved x position is :" + value);
        }
        public override void moveVertical(int y)
        {
            int value = base.getPosition().getX() + y + spirit;
            if (value < 0) { value = 0; }
            if (value > 500) { value = 500; }
            base.getPosition().setX(value);
            Console.WriteLine("A moved y position is :" + value);
        }
        public void transform()
        {

            
            if (getVehicle() == true)
            {
                Console.WriteLine("Autobot transform");
                Console.WriteLine("After the transform the value for isVehicle is: False");
            }else{
                Console.WriteLine("Autobot transform");
                Console.WriteLine("After the transform the value for isVehicle is: True");
            }

                base.transform();
            

        }
        public Autobot(int life, int x, int y, Boolean isVehicle, int spirit)
        {
            if (life < 0 && life > 20)
            {
                life = 20;
            }
            else this.setLife(life);
            base.setVehicle(isVehicle);
            if (x < 0 && x > 20)
            {
                x = 250;
            }
            else this.setPosition(x,base.getY());

            if (y < 0 && y > 20)
            {
                y = 250;
            }
            else this.setPosition(base.getX(),y);

            if (spirit < 0 && spirit > 10)
            {
                spirit = 5;
            }
            else this.setSpirit(spirit);
        }
    }

    class Test
    {
        public static void Main(String[] args)
        {
            Autobot a = new Autobot(4, 15, 20, false, 5);
            int l = a.getLife();
            Console.WriteLine(l);
            int x = a.getX();
            Console.WriteLine(x);
            int y = a.getY();
            Console.WriteLine(y);
            Console.WriteLine(a.getVehicle());
            int s = a.getSpirit();
            Console.WriteLine(s);

            a = new Autobot(-1, 15, 20, false, 5);
            Console.WriteLine(a.getLife());
            a = new Autobot(21, 15, 20, false, 5);
            Console.WriteLine(a.getLife());
            a = new Autobot(4, -1, 20, false, 5);
            Console.WriteLine(a.getX());
            a = new Autobot(4, 501, 20, false, 5);
            Console.WriteLine(a.getX());
            a = new Autobot(4, 15, -1, false, 5);
            Console.WriteLine(a.getY());
            a = new Autobot(4, 15, 501, false, 5);
            Console.WriteLine(a.getY());

            a = new Autobot(4, 15, 20, false, -1);
            Console.WriteLine(a.getSpirit());
            a = new Autobot(4, 15, 20, false, 11);
            Console.WriteLine(a.getSpirit());

            a.transform();
            a.transform();

            a.setPosition(250, a.getY());
            a.moveHorizontal(5);
            
          
            a.setPosition(a.getX(), 250);
            a.moveVertical(5);
            
            a.setPosition(0, a.getY());
            a.moveHorizontal(-40);

            a.setPosition(480, a.getY());
            a.moveHorizontal(40);
            Console.ReadLine();
        }
        
      
    }
}






